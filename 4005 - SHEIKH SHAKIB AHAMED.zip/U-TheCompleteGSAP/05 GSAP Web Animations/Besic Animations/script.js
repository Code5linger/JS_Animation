/*
TweenMax.to(".circle", 2, {
  backgroundColor: "red",
  x: 200,
  ease: Elastic.easeOut,
});

TweenMax.to(".circle", 2, {
  backgroundColor: "red",
  x: 200,
  ease: Elastic.easeIn,
});

TweenMax.to(".circle", 2, {
  backgroundColor: "red",
  x: 200,
  ease: Elastic.easeInOut,
});
*/
gsap.to(".logo", {
  duration: 2,
  x: 300,
  backgroundColor: "#124563",
  border: "5px solid white",
  borderRadius: "10%",
});
