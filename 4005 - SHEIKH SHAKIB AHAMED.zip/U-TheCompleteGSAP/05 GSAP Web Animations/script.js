/*
TweenMax.to(".circle", 2, {
  backgroundColor: "red",
  x: 200,
  ease: Elastic.easeOut,
});
*/
//1
/*
TweenMax.to(".circle", 3, {
  backgroundColor: "crimson",
  x: 200,
  ease: Elastic.easeOut,
});
*/
//2
/*
TweenMax.to(".circle", 2, {
  backgroundColor: "red",
  x: -200,
  ease: Elastic.easeOut,
});
*/
//3
/*
TweenMax.to(".circle", 2, {
  backgroundColor: "red",
  x: 200,
  y: 100,
  ease: Elastic.easeOut,
});
*/
//4
/*
TweenMax.to(".circle", 2, {
  backgroundColor: "green",
  x: -350,
  ease: Elastic.easeOut,
});
*/
//5
/*
TweenMax.to(".circle", 2, {
  backgroundColor: "gray",
  x: 400,
  ease: Elastic.easeIn,
});
*/
//6
/*
TweenMax.to(".circle", 2, {
  backgroundColor: "red",
  x: 350,
  ease: Elastic.easeOut,
});
*/
//7
/*
TweenMax.to(".circle", 2, {
  background: "red",
  x: 350,
  ease: Elastic.easeIn,
});
*/
//8
/*
TweenMax.to(".circle", 2, {
  backgroundColor: "red",
  x: 350,
  ease: Elastic.easeOut,
});
*/
//9
/*
TweenMax.to(".circle", 2, {
  backgroundColor: "red",
  x: 350,
  ease: Elastic.easeOut,
});
*/
//10
/*
TweenMax.to(".circle", 2, {
  backgroundColor: "red",
  x: 350,
  ease: Elastic.easeOut,
});
*/
//gsap.to(".logo", { duration: 2, x: 300 });
/*
gsap.to(".logo", {
  duration: 2,
  x: 300,
  backgroundColor: "#124563",
  borderRadius: "10%",
  border: "5px solid white",
  ease: "elastic",
});
gsap.to(".logo, .autocad", { transformOrigin: "50% 50%" });
gsap.to(".logo, .autocad", { duration: 20, rotation: 360 });
*/
/*
gsap.from(".logo", { duration: 1.5, opacity: 0, scale: 0.3, ease: "bounce" });
*/
/*
gsap.from(".circle", {
  duration: 1,
  opacity: 0,
  y: "random(-200,200)",
  stagger: 0.25,
});
*/
let tl = gsap.timeline({ repeat: 2 });

tl.from(".logo", {
  duration: 1.5,
  opacity: 0,
  scale: 0.3,
  ease: "back",
});

tl.to(".logo", { duration: 1, rotation: 360 });

tl.from(
  ".circle",
  {
    duration: 1,
    opacity: 0,
    delay: 1.5,
    y: 150,
    stagger: 0.25,
  },
  "+=1"
);


